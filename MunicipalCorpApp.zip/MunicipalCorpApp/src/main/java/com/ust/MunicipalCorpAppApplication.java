package com.ust;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MunicipalCorpAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MunicipalCorpAppApplication.class, args);
	}

}
