package com.ust.service;
import java.util.List; 
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ust.model.Mofficer; 
 @Service
public interface IOfficerService { 
  	public Integer saveOperator(Mofficer s);  	
public List<Mofficer>getAllOperator();  	
public Optional<Mofficer> getOneOperator(Integer id);  public boolean isExist(Integer id);  	
public void deleteOperator(Integer id); 
}

