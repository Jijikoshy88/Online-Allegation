package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.Complaint;

public interface IComplaintService {

	public List<Complaint> getAllComplaints();

	public Integer saveComplaint(Complaint complaint);

	public Optional<Complaint> getOneComplaint(Integer id);

}

