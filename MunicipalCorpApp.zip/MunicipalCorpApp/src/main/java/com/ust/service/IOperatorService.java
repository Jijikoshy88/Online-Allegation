package com.ust.service;
import java.util.List; 
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ust.model.Moperator; 
 @Service
public interface IOperatorService { 
  	public Integer saveOperator(Moperator s);  	
public List<Moperator>getAllOperator();  	
public Optional<Moperator> getOneOperator(Integer id);  public boolean isExist(Integer id);  	
public void deleteOperator(Integer id); 
}


