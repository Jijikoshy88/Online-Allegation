package com.ust.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Complaint;
import com.ust.repo.ComplaintRepository;
import com.ust.service.IComplaintService;

@Service
public class ComplaintServiceImpl implements IComplaintService {
	
	@Autowired 
	private ComplaintRepository repo; //HAS-A 

	@Override
	public List<Complaint> getAllComplaints() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Integer saveComplaint(Complaint s) {
		// TODO Auto-generated method stub
		return repo.save(s).getComId();
	}

	@Override
	public Optional<Complaint> getOneComplaint(Integer comId) {
		// TODO Auto-generated method stub
		return findById(comId);
	}

	private Optional<Complaint> findById(Integer comId) {
		// TODO Auto-generated method stub
		return null;
	}

}

