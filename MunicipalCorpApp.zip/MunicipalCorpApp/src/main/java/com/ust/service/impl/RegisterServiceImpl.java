package com.ust.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Register;

import com.ust.repo.RegisterRepository;
import com.ust.service.IRegisterService;



@Service
public class RegisterServiceImpl implements IRegisterService{
	
	@Autowired 
	private RegisterRepository repo; //HAS-A 


	@Override 
	public Integer saveRegister(Register s) { 
		return repo.save(s).getRegid(); 
	} 
	
	@Override 
	public List<Register> getAllRegisterations() {
		return repo.findAll(); 
	} 

	@Override 
	public Optional<Register> getOneRegister(Integer id) { 
		return repo.findById(id); 
	} 

	@Override 
	public boolean isExist(Integer id) { 
		return repo.existsById(id); 
	}

}
