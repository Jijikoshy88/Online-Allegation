
package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.Register;

public interface IRegisterService {

	public List<Register> getAllRegisterations();

	public Integer saveRegister(Register register);

	public Optional<Register> getOneRegister(Integer id);


	public boolean isExist(Integer id);  	

}
