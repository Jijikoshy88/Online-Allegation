package com.ust.service.impl;

import java.util.List; 
import java.util.Optional; 
 
import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service; 
 
import com.ust.model.Moperator; 
import com.ust.repo.OperatorRepository; 
import com.ust.service.IOperatorService; 

 @Service 
public class OperatorServiceImpl implements IOperatorService 
{ 
 	@Autowired 
 	private OperatorRepository repo; //HAS-A 
 	 
 	@Override 
 	public Integer saveOperator(Moperator s) { 
 	 	return repo.save(s).getOperatorId(); 
 	} 
 	@Override 
 	public List<Moperator> getAllOperator() {  	 		
 		return repo.findAll(); 
 	} 
 	 
 	@Override 
 	public Optional<Moperator> getOneOperator(Integer id) { 
 	 	return repo.findById(id); 
 	} 
 	 
 	@Override 
 	public void deleteOperator(Integer id) {  	 				repo.deleteById(id); 
 	} 
 	 
 	@Override 
 	public boolean isExist(Integer id) {  	return repo.existsById(id); 
}
 
}
