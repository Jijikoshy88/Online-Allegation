package com.ust.service.impl;

import java.util.List; 
import java.util.Optional; 
 
import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service; 
 
import com.ust.model.Mofficer;
import com.ust.repo.OfficerRepository;
import com.ust.service.IOfficerService; 

 @Service 
public class OfficerServiceImpl implements IOfficerService 
{ 
 	@Autowired 
 	private OfficerRepository repo; //HAS-A 
 	 
 	@Override 
 	public Integer saveOperator(Mofficer s) { 
 	 	return repo.save(s).getOfficerId(); 
 	} 
 	@Override 
 	public List<Mofficer> getAllOperator() {  	 		
 		return repo.findAll(); 
 	} 
 	 
 	@Override 
 	public Optional<Mofficer> getOneOperator(Integer id) { 
 	 	return repo.findById(id); 
 	} 
 	 
 	@Override 
 	public void deleteOperator(Integer id) {  	 				repo.deleteById(id); 
 	} 
 	 
 	@Override 
 	public boolean isExist(Integer id) {  	return repo.existsById(id); 
}
 
}
