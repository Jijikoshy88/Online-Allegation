package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data 
@NoArgsConstructor 
@RequiredArgsConstructor 
@AllArgsConstructor
@Entity 
public class Register {

	@Id 
 	@GeneratedValue 
 	private Integer regid;
	
	@NonNull 
	private String name;
	@NonNull 
	private String address;
	@NonNull 
	private String email;
	@NonNull 
	private String pincode;
	@NonNull 
	private String phone;
	@NonNull 
	private String password;
	
	
}

