package com.ust.model;
import javax.persistence.Entity; 
import javax.persistence.GeneratedValue; import javax.persistence.Id; 
 
import lombok.AllArgsConstructor; import lombok.Data; 
import lombok.NoArgsConstructor; import lombok.NonNull; 
import lombok.RequiredArgsConstructor; 

@Data 
@NoArgsConstructor 
@RequiredArgsConstructor 
@AllArgsConstructor 	@Entity 
public class Moperator { 
 	@Id 
 	@GeneratedValue  			
 	private Integer operatorId;  		@NonNull 
 	private String operatorName;  			@NonNull 
 	private String operatorPassword;  			@NonNull 
 	private String operatorUsername; 
}

