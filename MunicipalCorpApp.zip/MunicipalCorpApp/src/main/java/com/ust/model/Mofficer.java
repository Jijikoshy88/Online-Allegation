package com.ust.model;
import javax.persistence.Entity; 
import javax.persistence.GeneratedValue; import javax.persistence.Id; 
 
import lombok.AllArgsConstructor; import lombok.Data; 
import lombok.NoArgsConstructor; import lombok.NonNull; 
import lombok.RequiredArgsConstructor; 

@Data 
@NoArgsConstructor 
@RequiredArgsConstructor 
@AllArgsConstructor 	@Entity 
public class Mofficer { 
 	@Id 
 	@GeneratedValue  			
 	private Integer officerId;  		@NonNull 
 	private String officerName;  			@NonNull 
 	private String officerPassword;  			@NonNull 
 	private String officerUsername; 
}
