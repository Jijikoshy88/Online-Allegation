export class Userhome {
    comId: number=0;  
    email: string=" ";     
    category: string=" "; 

    description: string="";
}


