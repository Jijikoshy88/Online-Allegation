import { Component, OnInit } from '@angular/core';
import { Moperator } from '../moperator';
import { Message } from '../message';
import { MoperatorService } from '../moperator.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-moperator-all',
  templateUrl: './moperator-all.component.html',
  styleUrls: ['./moperator-all.component.css']
})
export class MoperatorAllComponent implements OnInit {
  moperators :Moperator[]=[];
  message :Message=new Message();
 

  constructor(private service:MoperatorService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllStudents(); 
  }  
  getAllStudents(){ 
    this.service.getAllOperators().subscribe(data=>{this.moperators=data},     
      error=>{        
         this.moperators=[] 
      });   } 
  deleteOperator(id:number){ 
    this.service.deleteOneOperator(id).subscribe( 
      data=>{         this.message=data,         this.getAllStudents(); 
      }, 
      error=>{console.log(error)} 
      ); 
       } 
  editOperator(id:number){ 
    this.router.navigate(['edit',id]); 
  } 
 
} 


