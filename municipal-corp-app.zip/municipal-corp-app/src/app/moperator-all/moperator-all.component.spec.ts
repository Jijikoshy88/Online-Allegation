import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoperatorAllComponent } from './moperator-all.component';

describe('MoperatorAllComponent', () => {
  let component: MoperatorAllComponent;
  let fixture: ComponentFixture<MoperatorAllComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoperatorAllComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MoperatorAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
