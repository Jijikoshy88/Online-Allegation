import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessoperatorComponent } from './successoperator.component';

describe('SuccessoperatorComponent', () => {
  let component: SuccessoperatorComponent;
  let fixture: ComponentFixture<SuccessoperatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuccessoperatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuccessoperatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
