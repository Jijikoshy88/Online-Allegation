import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successoperator',
  templateUrl: './successoperator.component.html',
  styleUrls: ['./successoperator.component.css']
})
export class SuccessoperatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
