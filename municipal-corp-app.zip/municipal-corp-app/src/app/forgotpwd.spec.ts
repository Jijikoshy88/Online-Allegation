import { Forgotpwd } from './forgotpwd';

describe('Forgotpwd', () => {
  it('should create an instance', () => {
    expect(new Forgotpwd()).toBeTruthy();
  });
});
