import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
//import {List} from './list';

import { Message } from './message';
import { Userhome } from './userhome';
@Injectable({
  providedIn: 'root'
})
export class UserhomeService {

  private baseUrl : string = 'http://localhost:9898/springboot-crud-rest/rest/complaint'; 

  constructor(private http:HttpClient) { } 
  
  getAllComplaints():Observable<Userhome[]>{ 
  return this.http.get<Userhome[]>(`${this.baseUrl}/call`); 
    }  
  createComplaint(userhome:Userhome):Observable<Message>{ 
  return this.http.post<Message>(`${this.baseUrl}/csave`,userhome); 
    } 
  
}
