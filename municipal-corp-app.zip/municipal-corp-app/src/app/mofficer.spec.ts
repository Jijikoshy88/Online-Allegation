import { Mofficer } from './mofficer';

describe('Mofficer', () => {
  it('should create an instance', () => {
    expect(new Mofficer()).toBeTruthy();
  });
});
