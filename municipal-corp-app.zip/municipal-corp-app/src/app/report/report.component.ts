import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';
import { Moperator } from '../moperator';
import { MoperatorService } from '../moperator.service';

import * as pdfMake from 'pdfmake/build/pdfmake.js';
// import * as pdfFonts from "pdfmake/build/vfs_fonts";
import * as pdfFonts from "pdfmake/build/vfs_fonts";
declare var require: any;
const htmlToPdfmake = require("html-to-pdfmake");
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  moperator :Moperator[]=[]; 
  message  : Message = new Message(); 
  
  @ViewChild('pdfTable')
  pdfTable!: ElementRef;
  
  public downloadAsPDF() {
    const pdfTable = this.pdfTable.nativeElement;
    var html = htmlToPdfmake(pdfTable.innerHTML);
    const documentDefinition = { content: html };
    pdfMake.createPdf(documentDefinition).download(); 
     
  }

  constructor(private service:MoperatorService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllOperators(); 
  }  

  
  getAllOperators(){ 
    this.service.getAllOperators().subscribe(data=>{this.moperator=data}
,       error=>{this.moperator=[] 
      });   } 

      editProduct(pid:number){ 
        this.router.navigate(['pdtedit',pid]); 
      } 

}
