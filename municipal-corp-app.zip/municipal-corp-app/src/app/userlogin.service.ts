import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Register } from './register';
import { Userlogin } from './userlogin';
import { Message } from './message';
@Injectable({
  providedIn: 'root'
})
export class UserloginService {
  private baseUrl : string = 'http://localhost:9898/springboot-crud-rest/rest/login'; 

  constructor(private http:HttpClient) { } 
  
  getAllRegistrations():Observable<Register[]>{ 
  return this.http.get<Register[]>(`${this.baseUrl}/all`); 
    }  
 

  createLogin(userlogin:Userlogin):Observable<Message>{ 
  return this.http.post<Message>(`${this.baseUrl}/save`,userlogin); 
    }  
  
}
