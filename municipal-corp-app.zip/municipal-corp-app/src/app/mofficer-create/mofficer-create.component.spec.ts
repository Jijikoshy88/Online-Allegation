import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MofficerCreateComponent } from './mofficer-create.component';

describe('MofficerCreateComponent', () => {
  let component: MofficerCreateComponent;
  let fixture: ComponentFixture<MofficerCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MofficerCreateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MofficerCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
