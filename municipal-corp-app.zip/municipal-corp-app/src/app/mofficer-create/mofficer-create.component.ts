import { Component, OnInit } from '@angular/core';
import { Mofficer } from '../mofficer';
import { Message } from '../message';
import { MofficerService } from '../mofficer.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-mofficer-create',
  templateUrl: './mofficer-create.component.html',
  styleUrls: ['./mofficer-create.component.css']
})
export class MofficerCreateComponent implements OnInit {
  mofficer : Mofficer = new Mofficer();  
  message : Message = new Message(); 
 
  constructor(private service:MofficerService,private router:Router) { }  
  ngOnInit(): void { 
   } 
  createOperator(){ 
    this.service.createOperator(this.mofficer).subscribe(data=>{       this.message=data; 
    }); 
    this.mofficer=new Mofficer(); 
  } 
 
} 


