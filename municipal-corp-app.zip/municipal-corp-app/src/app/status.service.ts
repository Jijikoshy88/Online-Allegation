import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Userhome } from './userhome';

@Injectable({
  providedIn: 'root'
})
export class StatusService {
  private baseUrl : string = 'http://localhost:9898/springboot-crud-rest/rest/complaint'; 

  constructor(private http:HttpClient) { } 
  
  getAllStatus():Observable<Userhome[]>{ 
  return this.http.get<Userhome[]>(`${this.baseUrl}/call`); 
    }  
 
}


