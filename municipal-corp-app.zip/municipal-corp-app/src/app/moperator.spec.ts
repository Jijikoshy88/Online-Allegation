import { Moperator } from './moperator';

describe('Moperator', () => {
  it('should create an instance', () => {
    expect(new Moperator()).toBeTruthy();
  });
});
