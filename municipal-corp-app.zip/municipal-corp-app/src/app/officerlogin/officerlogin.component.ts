import { Component, OnInit } from '@angular/core';
import { Mofficer } from '../mofficer';
import { Message } from '../message';
import { Router } from '@angular/router';
import { MofficerService } from '../mofficer.service';
@Component({
  selector: 'app-officerlogin',
  templateUrl: './officerlogin.component.html',
  styleUrls: ['./officerlogin.component.css']
})
export class OfficerloginComponent implements OnInit {
  username:string="";
  upwd:string="";
  mesg:string="";
  msg1:string="";
  msg2:string="";
  mofficer : Mofficer[]=[]; 
  message  : Message = new Message(); 
  constructor(private service:MofficerService,private route:Router) { }

  ngOnInit(): void {
  }
  loginClick(tx1:any)
  {      this.service.getAllOperators().subscribe(data=>{this.mofficer=data}
   ,       error=>{this.mofficer=[] 
         });
       //calling a service class method
     for(let s of this.mofficer){
         if(this.username==s.officerUsername  && this.upwd==s.officerPassword){

          this.route.navigate(['/successofficer']);
        
         } 
         else
         {
           this.mesg="Username or Password Incorrect";
           
           this.msg1=this.mesg;
         }
     }
 }
 }
 

