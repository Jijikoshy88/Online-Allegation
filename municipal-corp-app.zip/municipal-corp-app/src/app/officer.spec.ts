import { Officer } from './officer';

describe('Officer', () => {
  it('should create an instance', () => {
    expect(new Officer()).toBeTruthy();
  });
});
