import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';
import { Userhome } from '../userhome';
import { UserhomeService } from '../userhome.service';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {  
  // list : List[]=[]; 
  userhome : Userhome = new Userhome();
  // list: string = ""

  message  : Message = new Message(); 
  getAllComplaints: any;

  constructor(private service:UserhomeService, private router:Router) {
 } 
 
  ngOnInit(): void {    
     this.getAllComplaints(); 
  } 
  comId:number=0; 
  
  email:string="";
  category:string="";
  description:string=" ";

      createComplaint(){ 
        this.service.createComplaint(this.userhome).subscribe((data)=>{       
          this.message=data; 
        }); 
        this.userhome=new Userhome(); 
    
      }

}


