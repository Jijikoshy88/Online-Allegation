import { Component, OnInit } from '@angular/core';
import { Mofficer } from '../mofficer';
import { Message } from '../message';
import { MofficerService } from '../mofficer.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-mofficer-all',
  templateUrl: './mofficer-all.component.html',
  styleUrls: ['./mofficer-all.component.css']
})
export class MofficerAllComponent implements OnInit {

  mofficers :Mofficer[]=[];
  message :Message=new Message();
 

  constructor(private service:MofficerService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllStudents(); 
  }  
  getAllStudents(){ 
    this.service.getAllOperators().subscribe(data=>{this.mofficers=data},     
      error=>{        
         this.mofficers=[] 
      });   } 
  deleteOperator(id:number){ 
    this.service.deleteOneOperator(id).subscribe( 
      data=>{         this.message=data,         this.getAllStudents(); 
      }, 
      error=>{console.log(error)} 
      ); 
       } 
  editOperator(id:number){ 
    this.router.navigate(['oedit',id]); 
  } 
 
} 


