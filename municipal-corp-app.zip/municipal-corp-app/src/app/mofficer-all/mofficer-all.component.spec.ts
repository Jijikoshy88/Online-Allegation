import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MofficerAllComponent } from './mofficer-all.component';

describe('MofficerAllComponent', () => {
  let component: MofficerAllComponent;
  let fixture: ComponentFixture<MofficerAllComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MofficerAllComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MofficerAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
