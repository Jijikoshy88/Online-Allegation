import { Component, OnInit } from '@angular/core';
import { Moperator } from '../moperator';
import { MoperatorService } from '../moperator.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-moperator-edit',
  templateUrl: './moperator-edit.component.html',
  styleUrls: ['./moperator-edit.component.css']
})
export class MoperatorEditComponent implements OnInit {
  moperator:Moperator=new Moperator(); 
  id : number=0; 
   
    constructor(private service:MoperatorService,private activeRouter:ActivatedRoute, private router:Router) { } 
   
    ngOnInit(): void {     this.moperator =new Moperator(); 
      this.id=this.activeRouter.snapshot.params['id'];     
      this.service.getOneOperator(this.id).subscribe(       data=>{ 
          this.moperator=data; 
        } 
      );  
     }  
     updateOperator(){ 
      this.service.updateOperator(this.moperator).subscribe(data=>{       
        console.log(data), 
   
       this.router.navigate(['/all']);
    } );
   
  } 
  }
