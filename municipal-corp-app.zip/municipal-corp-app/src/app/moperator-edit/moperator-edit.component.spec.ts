import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoperatorEditComponent } from './moperator-edit.component';

describe('MoperatorEditComponent', () => {
  let component: MoperatorEditComponent;
  let fixture: ComponentFixture<MoperatorEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoperatorEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MoperatorEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
