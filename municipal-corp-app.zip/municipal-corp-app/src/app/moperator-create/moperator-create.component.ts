import { Component, OnInit } from '@angular/core';
import { Moperator } from '../moperator';
import { Message } from '../message';
import { MoperatorService } from '../moperator.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-moperator-create',
  templateUrl: './moperator-create.component.html',
  styleUrls: ['./moperator-create.component.css']
})
export class MoperatorCreateComponent implements OnInit {
  moperator : Moperator = new Moperator();  
  message : Message = new Message(); 
 
  constructor(private service:MoperatorService,private router:Router) { }  
  ngOnInit(): void { 
   } 
  createOperator(){ 
    this.service.createOperator(this.moperator).subscribe(data=>{       this.message=data; 
    }); 
    this.moperator=new Moperator(); 
  } 
 
} 


