import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoperatorCreateComponent } from './moperator-create.component';

describe('MoperatorCreateComponent', () => {
  let component: MoperatorCreateComponent;
  let fixture: ComponentFixture<MoperatorCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoperatorCreateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MoperatorCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
