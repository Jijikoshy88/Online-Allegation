import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Moperator } from './moperator';
import { Observable } from 'rxjs'; 
import { Message } from './message'; 

@Injectable({
  providedIn: 'root'
})
export class MoperatorService {
  private baseUrl : string = 'http://localhost:9898/springboot-crud-rest/rest/student'; 
 
  constructor(private http:HttpClient) { } 
 
  getAllOperators():Observable<Moperator[]>{ 
    return this.http.get<Moperator[]>(`${this.baseUrl}/all`); 
  }  
  deleteOneOperator(id:number):Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/remove/${id}`); 
  }  
  createOperator(operator:Moperator):Observable<Message>{ 
    return this.http.post<Message>(`${this.baseUrl}/save`,operator); 
  }  
  getOneOperator(id:number):Observable<Moperator>{ 
    return this.http.get<Moperator>(`${this.baseUrl}/one/${id}`); 
  }  
  updateOperator(operator:Moperator):Observable<Message>{ 
   return this.http.put<Message>(`${this.baseUrl}/update`,operator); 
  } 
} 
 
