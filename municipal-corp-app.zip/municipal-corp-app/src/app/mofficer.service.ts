import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Moperator } from './moperator';
import { Observable } from 'rxjs'; 
import { Message } from './message'; 
import { Mofficer } from './mofficer';

@Injectable({
  providedIn: 'root'
})
export class MofficerService {
  private baseUrl : string = 'http://localhost:9898/springboot-crud-rest/rest/officer'; 
 
  constructor(private http:HttpClient) { } 
 
  getAllOperators():Observable<Mofficer[]>{ 
    return this.http.get<Mofficer[]>(`${this.baseUrl}/oall`); 
  }  
  deleteOneOperator(id:number):Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/oremove/${id}`); 
  }  
  createOperator(operator:Mofficer):Observable<Message>{ 
    return this.http.post<Message>(`${this.baseUrl}/osave`,operator); 
  }  
  getOneOperator(id:number):Observable<Mofficer>{ 
    return this.http.get<Mofficer>(`${this.baseUrl}/one/${id}`); 
  }  
  updateOperator(operator:Mofficer):Observable<Message>{ 
   return this.http.put<Message>(`${this.baseUrl}/oupdate`,operator); 
  } 
} 
 
