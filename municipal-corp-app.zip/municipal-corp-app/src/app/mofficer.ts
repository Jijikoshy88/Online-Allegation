export class Mofficer {
    officerId:number=0;
    officerName : string=""; 
    officerPassword : string="";    
    officerUsername: string="";     
}

