import { Userhome } from './userhome';

describe('Userhome', () => {
  it('should create an instance', () => {
    expect(new Userhome()).toBeTruthy();
  });
});
