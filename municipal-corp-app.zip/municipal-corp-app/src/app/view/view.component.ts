import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';
import { Register } from '../register';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  register : Register[]=[]; 
  message  : Message = new Message(); 
 
  constructor(private service:RegisterService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllRegistrations(); 
  }  

  
  getAllRegistrations(){ 
    this.service.getAllRegistrations().subscribe(data=>{this.register=data}
,       error=>{this.register=[] 
      });   } 

      

}

