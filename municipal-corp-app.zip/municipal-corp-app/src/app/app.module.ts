import { NgModule } from '@angular/core';
import{HttpClientModule} from '@angular/common/http' 
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MoperatorAllComponent } from './moperator-all/moperator-all.component';
import { MoperatorCreateComponent } from './moperator-create/moperator-create.component';
import { MoperatorEditComponent } from './moperator-edit/moperator-edit.component';
import { MofficerAllComponent } from './mofficer-all/mofficer-all.component';
import { MofficerCreateComponent } from './mofficer-create/mofficer-create.component';
import { MofficerEditComponent } from './mofficer-edit/mofficer-edit.component';
import { AdminComponent } from './admin/admin.component';
import { ForgotpwdComponent } from './forgotpwd/forgotpwd.component';
import { NewpwdComponent } from './newpwd/newpwd.component';
import { LoginComponent } from './login/login.component';
import { OperatorloginComponent } from './operatorlogin/operatorlogin.component';
import { SuccessoperatorComponent } from './successoperator/successoperator.component';
import { OfficerloginComponent } from './officerlogin/officerlogin.component';
import { SuccessofficerComponent } from './successofficer/successofficer.component';
import { RegisterComponent } from './register/register.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { StatusComponent } from './status/status.component';
import { ViewComponent } from './view/view.component';
import { UserstatusComponent } from './userstatus/userstatus.component';
import { ReportComponent } from './report/report.component';
import { OfficerreportComponent } from './officerreport/officerreport.component';

@NgModule({
  declarations: [
    AppComponent,
    MoperatorAllComponent,
    MoperatorCreateComponent,
    MoperatorEditComponent,
    MofficerAllComponent,
    MofficerCreateComponent,
    MofficerEditComponent,
    AdminComponent,
    ForgotpwdComponent,
    NewpwdComponent,
    LoginComponent,
    OperatorloginComponent,
    SuccessoperatorComponent,
    OfficerloginComponent,
    SuccessofficerComponent,
    RegisterComponent,
    UserloginComponent,
    UserhomeComponent,
    StatusComponent,
    ViewComponent,
    UserstatusComponent,
    ReportComponent,
    OfficerreportComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
