export class Moperator {
    operatorId:number=0;
    operatorName : string=""; 
    operatorPassword : string="";    
    operatorUsername: string="";     
}
