import { Component, OnInit } from '@angular/core';
import { Userhome } from '../userhome';
import { Message } from '../message';
import { StatusService } from '../status.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {
  userhome : Userhome[]=[]; 
  message  : Message = new Message(); 
 
  constructor(private service:StatusService, private router:Router) {
 } 
 
  ngOnInit(): void {    
     this.getAllStatus(); 
  }  

  
  getAllStatus(){ 
    this.service.getAllStatus().subscribe(data=>{this.userhome=data}
,       error=>{this.userhome=[] 
      });   } 

}

