import { TestBed } from '@angular/core/testing';

import { MoperatorService } from './moperator.service';

describe('MoperatorService', () => {
  let service: MoperatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MoperatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
