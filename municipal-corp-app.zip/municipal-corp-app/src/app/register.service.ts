import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Message } from './message';
import { Register } from './register';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  private baseUrl : string = 'http://localhost:9898/springboot-crud-rest/rest/register'; 

  constructor(private http:HttpClient) { } 
  
  getAllRegistrations():Observable<Register[]>{ 
  return this.http.get<Register[]>(`${this.baseUrl}/rall`); 
    }  
  deleteOneStudent(id:number):Observable<Message>{ 
  return this.http.delete<Message>(`${this.baseUrl}/remove/${id}`); 
    }  
  createRegister(register:Register):Observable<Message>{ 
  return this.http.post<Message>(`${this.baseUrl}/rsave`,register); 
    }  
  getOneStudent(id:number):Observable<Register>{ 
  return this.http.get<Register>(`${this.baseUrl}/one/${id}`); 
    }  
  updateStudent(register:Register):Observable<Message>{ 
  return this.http.put<Message>(`${this.baseUrl}/rupdate`,register); 
    } 
}

