import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Message } from '../message';
@Component({
  selector: 'app-newpwd',
  templateUrl: './newpwd.component.html',
  styleUrls: ['./newpwd.component.css']
})
export class NewpwdComponent implements OnInit {

  constructor(private router:Router,private _activatedRoute: ActivatedRoute) { }
  message  : Message = new Message(); 
  myClass:string="";
  ngOnInit(): void {
  }

}
