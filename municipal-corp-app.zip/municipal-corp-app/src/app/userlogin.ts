export class Userlogin {
    email:string=" ";
    password:string=" ";
}

