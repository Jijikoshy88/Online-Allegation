import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessofficerComponent } from './successofficer.component';

describe('SuccessofficerComponent', () => {
  let component: SuccessofficerComponent;
  let fixture: ComponentFixture<SuccessofficerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuccessofficerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuccessofficerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
