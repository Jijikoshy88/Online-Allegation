import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successofficer',
  templateUrl: './successofficer.component.html',
  styleUrls: ['./successofficer.component.css']
})
export class SuccessofficerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
