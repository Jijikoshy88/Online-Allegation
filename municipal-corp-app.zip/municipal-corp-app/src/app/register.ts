export class Register {

    regid: number=0;  
    name: string=" ";     
    address: string=" "; 

    email: string=""; 
    pincode:string=" ";
    phone: string=" ";
    password: string=" ";
   
}
