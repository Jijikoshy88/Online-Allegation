import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Userhome } from '../userhome';
import { UserhomeService } from '../userhome.service';

@Component({
  selector: 'app-userstatus',
  templateUrl: './userstatus.component.html',
  styleUrls: ['./userstatus.component.css']
})
export class UserstatusComponent implements OnInit {

  constructor(private service:UserhomeService, private router: Router) { }

  userhome: Userhome[] = [];

  // comId:number=0; 
  strId:string="";
  strEm:string="";
  strCat:string="";
  email:string="";
  category:string="";
  description:string=" ";

  ngOnInit(): void {
    this.service.getAllComplaints().subscribe(data => {
      this.userhome = data;
     this.userhome = this.userhome
    });
  }
 
 search(){
    this.userhome = this.userhome.filter((e1) => {
      if (e1.email.toLowerCase().indexOf(this.strEm.toLowerCase()) >= 0)
        return e1.email.toLowerCase().indexOf(this.strEm.toLowerCase()) >= 0

      else if(e1.category.toLowerCase().indexOf(this.strCat.toLowerCase()) >= 0)
        return e1.category.toLowerCase().indexOf(this.strCat.toLowerCase()) >= 0
      else
        return e1.comId.toPrecision().indexOf(this.strId)>=0  })
       this.router.navigate(['/userstatus'])
  }
 
  

}
