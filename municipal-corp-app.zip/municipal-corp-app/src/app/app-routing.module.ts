import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MofficerCreateComponent } from './mofficer-create/mofficer-create.component';
import { MofficerAllComponent } from './mofficer-all/mofficer-all.component';
import { MofficerEditComponent } from './mofficer-edit/mofficer-edit.component';
import { MoperatorAllComponent } from './moperator-all/moperator-all.component';
import { MoperatorCreateComponent } from './moperator-create/moperator-create.component';
import { MoperatorEditComponent } from './moperator-edit/moperator-edit.component';
import { AdminComponent } from './admin/admin.component';
import { ForgotpwdComponent } from './forgotpwd/forgotpwd.component';
import { NewpwdComponent } from './newpwd/newpwd.component';
import { LoginComponent } from './login/login.component';
import { SuccessoperatorComponent } from './successoperator/successoperator.component';
import { OperatorloginComponent } from './operatorlogin/operatorlogin.component';
import { OfficerloginComponent } from './officerlogin/officerlogin.component';
import { SuccessofficerComponent } from './successofficer/successofficer.component';
import { RegisterComponent } from './register/register.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { StatusComponent } from './status/status.component';
import { ViewComponent } from './view/view.component';
import { UserstatusComponent } from './userstatus/userstatus.component';
import { ReportComponent } from './report/report.component';
import { OfficerreportComponent } from './officerreport/officerreport.component';
const routes: Routes = [
  {path:'oall',component:MofficerAllComponent}, 
  {path:'oadd',component:MofficerCreateComponent}, 
  {path:'oedit/:id',component:MofficerEditComponent}, 
  {path:'',redirectTo:'',pathMatch:'full'}, 
  {path:'rall',component:RegisterComponent},
  {path:'rsave',component:RegisterComponent},
  {path:'rupdate',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  {path:'successoperator',component:SuccessoperatorComponent},
  {path:'operatorlogin',component:OperatorloginComponent},
  //{path:'/new',component:NewpwdComponent},
  {path:'all',component:MoperatorAllComponent}, 
  {path:'add',component:MoperatorCreateComponent}, 
  {path:'edit/:id',component:MoperatorEditComponent}, 
  {path:'newadmin',component:AdminComponent},
  {path:'forgotpwd',component:ForgotpwdComponent},
  {path:'officerlogin',component:OfficerloginComponent},
  {path: 'successofficer',component:SuccessofficerComponent},
  {path:'register',component:RegisterComponent},
  {path:'sign',component:UserloginComponent},
  {path:'userhome',component:UserhomeComponent},
{path:'csave',component:UserhomeComponent},
{path:'call',component:UserhomeComponent},
{path:'status',component:StatusComponent},
{path:'view',component:ViewComponent},
{path:'search',component:UserstatusComponent},
{path:'pdtedit',component:ReportComponent},
{path:'ofredit',component:OfficerreportComponent},
  {path:'',redirectTo:'',pathMatch:'full'}
  
]; 


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

