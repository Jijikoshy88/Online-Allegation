import { TestBed } from '@angular/core/testing';

import { MofficerService } from './mofficer.service';

describe('MofficerService', () => {
  let service: MofficerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MofficerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
