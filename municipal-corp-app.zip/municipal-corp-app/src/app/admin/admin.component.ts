import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; 

import { Admin } from '../admin';
import { Message } from '../message';
import { AdminService } from '../admin.service';
import { ActivatedRoute,Route } from '@angular/router';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  admin :Admin =new Admin();
  message  : Message = new Message(); 
  myClass:string="";
 mesg: string="";
  constructor(private service:AdminService,private router:Router,private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
  }
  loginClick(){
    if(this.admin.username=="admin"&&this.admin.password=="admin")
    {
      //this.message.mesg="Welcome" +" " + this.admin.username + "!!!";
     
      this.router.navigate(['/login']);
    }
    else
    {
      this.message.mesg="Invalid login";

    }
   
}
go(){
  this.router.navigate(['/forgotpwd']); // navigate to other page
  
}

}


