import { Component, OnInit } from '@angular/core';
import { Userlogin } from '../userlogin';
import { Register } from '../register';
import { Message } from '../message';
import { UserloginService } from '../userlogin.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  ngOnInit(): void {
    
  }

  email:string="";
  password:string="";
  msg:string="";
  msg1:string="";
  msg2:string="";
userlogin:Userlogin[]=[];
  register : Register[]=[];
  message  : Message = new Message(); 
  constructor(private service:UserloginService,private route:Router)
  {
  }

  loginClick(tx1:any)
 {      this.service.getAllRegistrations().subscribe(data=>{this.register=data}
  ,       error=>{this.register=[] 
        });
      //calling a service class method
    for(let s of this.register){
        if(this.email==s.email  && this.password==s.password){
          
        this.route.navigate(['/user']);
        } 
        else
        {
          this.msg="Username or Password Incorrect";
       
          this.msg1=this.msg;
        }
    }
}
}
