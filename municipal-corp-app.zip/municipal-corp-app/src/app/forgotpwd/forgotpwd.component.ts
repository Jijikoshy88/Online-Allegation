import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Message } from '../message';
@Component({
  selector: 'app-forgotpwd',
  templateUrl: './forgotpwd.component.html',
  styleUrls: ['./forgotpwd.component.css']
})
export class ForgotpwdComponent implements OnInit {
  message  : Message = new Message(); 
  myClass:string="";
  constructor(private router:Router,private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
  }
  newpwd(){
    this.router.navigate(['/new']);
}
}
