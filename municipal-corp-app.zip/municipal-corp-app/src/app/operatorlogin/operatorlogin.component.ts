import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';
import { Moperator } from '../moperator';
import { MoperatorService } from '../moperator.service';

@Component({
  selector: 'app-operatorlogin',
  templateUrl: './operatorlogin.component.html',
  styleUrls: ['./operatorlogin.component.css']
})
export class OperatorloginComponent implements OnInit {
  username:string="";
  upwd:string="";
  mesg:string="";
  msg1:string="";
  msg2:string="";
  moperator : Moperator[]=[]; 
  message  : Message = new Message(); 
  constructor(private service:MoperatorService,private route:Router) { }

  ngOnInit(): void {
  }
  loginClick(tx1:any)
  {      this.service.getAllOperators().subscribe(data=>{this.moperator=data}
   ,       error=>{this.moperator=[] 
         });
       //calling a service class method
     for(let s of this.moperator){
         if(this.username==s.operatorUsername  && this.upwd==s.operatorPassword){

          this.route.navigate(['/successoperator']);
        
         } 
         else
         {
           this.mesg="Username or Password Incorrect";
           
           this.msg1=this.mesg;
         }
     }
 }
 }
 

