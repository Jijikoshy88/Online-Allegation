import { Component, OnInit } from '@angular/core';
import { Mofficer } from '../mofficer';
import { MofficerService } from '../mofficer.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mofficer-edit',
  templateUrl: './mofficer-edit.component.html',
  styleUrls: ['./mofficer-edit.component.css']
})
export class MofficerEditComponent implements OnInit {
  mofficer:Mofficer=new Mofficer(); 
  id : number=0; 
   
    constructor(private service:MofficerService,private activeRouter:ActivatedRoute, private router:Router) { } 
   
    ngOnInit(): void {     this.mofficer =new Mofficer(); 
      this.id=this.activeRouter.snapshot.params['id'];     
      this.service.getOneOperator(this.id).subscribe(       data=>{ 
          this.mofficer=data; 
        } 
      );  
     }  
     updateOperator(){ 
      this.service.updateOperator(this.mofficer).subscribe(data=>{       
        console.log(data), 
   
       this.router.navigate(['/oall']);
    } );
   
  } 
  }
