import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MofficerEditComponent } from './mofficer-edit.component';

describe('MofficerEditComponent', () => {
  let component: MofficerEditComponent;
  let fixture: ComponentFixture<MofficerEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MofficerEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MofficerEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
