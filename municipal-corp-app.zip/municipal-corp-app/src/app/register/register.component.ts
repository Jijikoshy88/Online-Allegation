import { Component, OnInit } from '@angular/core';
import { Message } from '../message';
import { Register } from '../register';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  register : Register = new Register();  
  message : Message = new Message(); 
  name : string ="";
  address : string ="";
  email : string ="";
  pincode : string ="";
  phone : string ="";
  password : string ="";

  constructor(private service:RegisterService,private router:Router) { }

  ngOnInit(): void {
  }

  createRegister(){ 
    this.service.createRegister(this.register).subscribe((data)=>{       
      this.message=data; 
    }); 
    this.register=new Register(); 

  }
}
